var cars = ["BMW", "Volvo", "Saab", "Ford"];
var i;
for (i = 0, l = cars.length, text = ""; i < l; i++) {
    text += cars[i] + "\n";
	console.log("car :"+text);
}
console.log("car :"+text);
alert("text"+text);