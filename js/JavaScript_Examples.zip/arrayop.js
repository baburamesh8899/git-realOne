var fruits = ["Banana", "Orange", "Apple", "Mango"];
var length=fruits.length;
alert(" Array length " + length);
console.log("Adding element to aray");
console.log("Array elemnts "+fruits);
fruits[fruits.length]="new fruit @ "+length;
console.log("Array elemnts "+fruits);